import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from '../hooks/useLocation';
import { useAppStore } from '../lib/store';
import { LanguageSelector } from './LanguageSelector';
import { MapPin, Volume2, Wifi, WifiOff, X } from 'lucide-react';

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Settings({ isOpen, onClose }: SettingsProps) {
  const { t } = useTranslation();
  const { requestPermission, hasPermission } = useLocation();
  const { voiceEnabled, offlineMode, toggleVoice, toggleOffline } = useAppStore();
  const [isRequestingLocation, setIsRequestingLocation] = useState(false);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleLocationToggle = async () => {
    if (!hasPermission) {
      setIsRequestingLocation(true);
      await requestPermission();
      setIsRequestingLocation(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-end sm:items-center justify-center">
      <div className="bg-white w-full sm:max-w-md sm:rounded-t-2xl rounded-t-3xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">{t('settings')}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X size={24} className="text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Language Settings */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('language')}</h3>
            <LanguageSelector />
          </div>

          {/* Feature Toggles */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">{t('settings')}</h3>
            
            {/* Voice Guide */}
            <div className="flex items-center justify-between p-4 rounded-xl border border-gray-200">
              <div className="flex items-center gap-3">
                <Volume2 size={24} className="text-gray-600" />
                <div>
                  <p className="font-medium text-gray-900">{t('voiceGuide')}</p>
                  <p className="text-sm text-gray-500">Enable voice responses</p>
                </div>
              </div>
              <button
                onClick={toggleVoice}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  voiceEnabled ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    voiceEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Location Services */}
            <div className="flex items-center justify-between p-4 rounded-xl border border-gray-200">
              <div className="flex items-center gap-3">
                <MapPin size={24} className="text-gray-600" />
                <div>
                  <p className="font-medium text-gray-900">{t('location')}</p>
                  <p className="text-sm text-gray-500">
                    {hasPermission ? 'Enabled' : 'Enable for nearby POIs'}
                  </p>
                </div>
              </div>
              <button
                onClick={handleLocationToggle}
                disabled={hasPermission || isRequestingLocation}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  hasPermission ? 'bg-blue-500' : 'bg-gray-300'
                } ${isRequestingLocation ? 'opacity-50' : ''}`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    hasPermission ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Offline Mode */}
            <div className="flex items-center justify-between p-4 rounded-xl border border-gray-200">
              <div className="flex items-center gap-3">
                {offlineMode ? <WifiOff size={24} className="text-gray-600" /> : <Wifi size={24} className="text-gray-600" />}
                <div>
                  <p className="font-medium text-gray-900">{t('offline')}</p>
                  <p className="text-sm text-gray-500">Save data for offline use</p>
                </div>
              </div>
              <button
                onClick={toggleOffline}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  offlineMode ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    offlineMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
