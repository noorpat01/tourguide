import { useTranslation } from 'react-i18next';
import { useConversationStore } from '../lib/store';
import { Check } from 'lucide-react';

const languages = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'zh', name: 'Chinese', nativeName: '中文' }
];

export function LanguageSelector() {
  const { i18n } = useTranslation();
  const { language, setLanguage } = useConversationStore();

  const handleLanguageChange = async (langCode: string) => {
    setLanguage(langCode);
    await i18n.changeLanguage(langCode);
  };

  return (
    <div className="space-y-2">
      {languages.map((lang) => {
        const isRTL = lang.code === 'ar' || lang.code === 'ur';
        const isSelected = language === lang.code;

        return (
          <button
            key={lang.code}
            onClick={() => handleLanguageChange(lang.code)}
            className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
              isSelected
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            } ${isRTL ? 'text-right' : 'text-left'}`}
          >
            <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={isRTL ? 'text-right' : 'text-left'}>
                <p className="font-medium text-gray-900">{lang.nativeName}</p>
                <p className="text-sm text-gray-500">{lang.name}</p>
              </div>
              {isSelected && (
                <div className="flex-shrink-0">
                  <Check size={20} className="text-blue-500" />
                </div>
              )}
            </div>
          </button>
        );
      })}
    </div>
  );
}
