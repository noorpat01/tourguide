import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useConversation } from '../hooks/useConversation';
import { useVoice } from '../hooks/useVoice';
import { useConversationStore } from '../lib/store';
import { Send, Mic, MicOff, Volume2 } from 'lucide-react';

export function ChatInterface() {
  const { t } = useTranslation();
  const { messages, sendMessage, isTyping } = useConversation();
  const { speak, stopSpeaking, startListening, stopListening, isListening, isSpeaking, isAvailable } = useVoice();
  const { language } = useConversationStore();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const messageText = input.trim();
    setInput('');
    
    try {
      const response = await sendMessage(messageText);
      
      // Auto-play voice response
      if (response?.message) {
        await speak(response.message, language);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening(language, (transcript) => {
        setInput(transcript);
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Global Stop Button */}
      {isSpeaking && (
        <div className="p-2 bg-red-50 border-b border-red-200">
          <button
            onClick={stopSpeaking}
            className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all text-sm"
            title="Stop all audio"
          >
            <Volume2 size={16} />
            <span>Stop Audio</span>
          </button>
        </div>
      )}

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-gray-500 mt-8">
            <p className="text-lg font-medium">{t('welcome')}</p>
            <p className="text-sm mt-2">Ask me anything about your travel destination</p>
          </div>
        )}
        
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                message.role === 'user'
                  ? 'bg-blue-500 text-white rounded-br-none'
                  : 'bg-gray-100 text-gray-800 rounded-bl-none'
              }`}
            >
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
              
              {message.role === 'assistant' && (
                <button
                  onClick={isSpeaking ? stopSpeaking : () => speak(message.content, language)}
                  className="mt-2 text-xs opacity-70 hover:opacity-100 flex items-center gap-1 transition-all"
                  title={isSpeaking ? 'Stop audio' : 'Play audio'}
                >
                  <Volume2 size={12} />
                  <span>{isSpeaking ? 'Stop' : 'Play'}</span>
                </button>
              )}
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-2xl rounded-bl-none px-4 py-3">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-gray-200 p-4 bg-white">
        <div className="flex items-end gap-2">
          {/* Voice Button */}
          {isAvailable && (
            <button
              onClick={handleVoiceInput}
              className={`flex-shrink-0 p-3 rounded-full transition-all ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              title={isListening ? t('listening') : t('tapToSpeak')}
            >
              {isListening ? <MicOff size={20} /> : <Mic size={20} />}
            </button>
          )}

          {/* Text Input */}
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t('typeMessage')}
              className="w-full px-4 py-3 pr-12 rounded-2xl border border-gray-300 focus:outline-none focus:border-blue-500 resize-none max-h-32"
              rows={1}
              style={{ minHeight: '48px' }}
            />
          </div>

          {/* Send Button */}
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="flex-shrink-0 p-3 rounded-full bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            title={t('send')}
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
