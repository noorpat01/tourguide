import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      welcome: "Welcome to your AI Travel Guide",
      tapToSpeak: "Tap to speak",
      or: "or",
      typeMessage: "Type your message...",
      send: "Send",
      listening: "Listening...",
      nearby: "Nearby Attractions",
      discover: "Discover",
      settings: "Settings",
      language: "Language",
      voiceGuide: "Voice Guide",
      offline: "Offline Mode",
      location: "Location Services",
      aboutPOI: "About this place",
      directions: "Get Directions",
      loading: "Loading...",
      error: "Something went wrong",
      retry: "Try Again"
    }
  },
  es: {
    translation: {
      welcome: "Bienvenido a tu Guía de Viaje AI",
      tapToSpeak: "Toca para hablar",
      or: "o",
      typeMessage: "Escribe tu mensaje...",
      send: "Enviar",
      listening: "Escuchando...",
      nearby: "Atracciones Cercanas",
      discover: "Descubrir",
      settings: "Configuración",
      language: "Idioma",
      voiceGuide: "Guía de Voz",
      offline: "Modo Sin Conexión",
      location: "Servicios de Ubicación",
      aboutPOI: "Acerca de este lugar",
      directions: "Obtener Direcciones",
      loading: "Cargando...",
      error: "Algo salió mal",
      retry: "Intentar de Nuevo"
    }
  },
  hi: {
    translation: {
      welcome: "अपने AI ट्रैवल गाइड में आपका स्वागत है",
      tapToSpeak: "बोलने के लिए टैप करें",
      or: "या",
      typeMessage: "अपना संदेश लिखें...",
      send: "भेजें",
      listening: "सुन रहे हैं...",
      nearby: "आस-पास के आकर्षण",
      discover: "खोजें",
      settings: "सेटिंग्स",
      language: "भाषा",
      voiceGuide: "वॉयस गाइड",
      offline: "ऑफलाइन मोड",
      location: "स्थान सेवाएं",
      aboutPOI: "इस जगह के बारे में",
      directions: "दिशा-निर्देश प्राप्त करें",
      loading: "लोड हो रहा है...",
      error: "कुछ गलत हो गया",
      retry: "पुनः प्रयास करें"
    }
  },
  ur: {
    translation: {
      welcome: "اپنے AI ٹریول گائیڈ میں خوش آمدید",
      tapToSpeak: "بولنے کے لیے تھپتھپائیں",
      or: "یا",
      typeMessage: "اپنا پیغام ٹائپ کریں...",
      send: "بھیجیں",
      listening: "سن رہے ہیں...",
      nearby: "قریبی پرکشش مقامات",
      discover: "دریافت کریں",
      settings: "ترتیبات",
      language: "زبان",
      voiceGuide: "آواز گائیڈ",
      offline: "آف لائن موڈ",
      location: "مقام کی خدمات",
      aboutPOI: "اس جگہ کے بارے میں",
      directions: "سمت حاصل کریں",
      loading: "لوڈ ہو رہا ہے...",
      error: "کچھ غلط ہو گیا",
      retry: "دوبارہ کوشش کریں"
    }
  },
  ar: {
    translation: {
      welcome: "مرحبًا بك في دليل السفر AI الخاص بك",
      tapToSpeak: "انقر للتحدث",
      or: "أو",
      typeMessage: "اكتب رسالتك...",
      send: "إرسال",
      listening: "الاستماع...",
      nearby: "المعالم القريبة",
      discover: "اكتشف",
      settings: "الإعدادات",
      language: "اللغة",
      voiceGuide: "الدليل الصوتي",
      offline: "وضع عدم الاتصال",
      location: "خدمات الموقع",
      aboutPOI: "حول هذا المكان",
      directions: "احصل على الاتجاهات",
      loading: "جارٍ التحميل...",
      error: "حدث خطأ ما",
      retry: "حاول مرة أخرى"
    }
  },
  fr: {
    translation: {
      welcome: "Bienvenue dans votre Guide de Voyage AI",
      tapToSpeak: "Appuyez pour parler",
      or: "ou",
      typeMessage: "Tapez votre message...",
      send: "Envoyer",
      listening: "Écoute...",
      nearby: "Attractions à Proximité",
      discover: "Découvrir",
      settings: "Paramètres",
      language: "Langue",
      voiceGuide: "Guide Vocal",
      offline: "Mode Hors Ligne",
      location: "Services de Localisation",
      aboutPOI: "À propos de ce lieu",
      directions: "Obtenir l'Itinéraire",
      loading: "Chargement...",
      error: "Une erreur s'est produite",
      retry: "Réessayer"
    }
  },
  zh: {
    translation: {
      welcome: "欢迎使用AI旅行指南",
      tapToSpeak: "点击说话",
      or: "或",
      typeMessage: "输入您的消息...",
      send: "发送",
      listening: "正在聆听...",
      nearby: "附近景点",
      discover: "发现",
      settings: "设置",
      language: "语言",
      voiceGuide: "语音导游",
      offline: "离线模式",
      location: "位置服务",
      aboutPOI: "关于这个地方",
      directions: "获取路线",
      loading: "加载中...",
      error: "出错了",
      retry: "重试"
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
