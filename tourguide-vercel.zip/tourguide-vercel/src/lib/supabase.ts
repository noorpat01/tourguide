import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://hbekiobfacrjaeskgtru.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhiZWtpb2JmYWNyamFlc2tndHJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgwNTkwOTIsImV4cCI6MjA3MzYzNTA5Mn0.fii9Zfj__fDtViy8M2WtarOppwMfPgcStIU8n6NMwCY";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
