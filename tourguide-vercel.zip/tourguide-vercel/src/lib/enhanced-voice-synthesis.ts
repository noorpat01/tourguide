Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { text, language, voiceStyle } = await req.json();

        if (!text || !language) {
            throw new Error('Text and language are required');
        }

        // Voice mapping for Web Speech API - Enhanced quality selection
        const voiceMapping = {
            'en': {
                'guide': 'enhanced_en_female',    // Will select best available English female
                'storyteller': 'enhanced_en_male', // Will select best available English male  
                'conversational': 'enhanced_en_natural' // Will select most natural English voice
            },
            'es': {
                'guide': 'enhanced_es_female',    // Best available Spanish female
                'storyteller': 'enhanced_es_male', // Best available Spanish male
                'conversational': 'enhanced_es_natural' // Most natural Spanish voice
            },
            'hi': {
                'guide': 'enhanced_hi_female',    // Best available Hindi female
                'storyteller': 'enhanced_hi_male', // Best available Hindi male
                'conversational': 'enhanced_hi_natural' // Most natural Hindi voice
            },
            'ur': {
                'guide': 'enhanced_ur_female',    // Best available Urdu female
                'storyteller': 'enhanced_ur_male', // Best available Urdu male
                'conversational': 'enhanced_ur_natural' // Most natural Urdu voice
            },
            'ar': {
                'guide': 'enhanced_ar_female',    // Best available Arabic female
                'storyteller': 'enhanced_ar_male', // Best available Arabic male
                'conversational': 'enhanced_ar_natural' // Most natural Arabic voice
            },
            'fr': {
                'guide': 'enhanced_fr_female',    // Best available French female
                'storyteller': 'enhanced_fr_male', // Best available French male
                'conversational': 'enhanced_fr_natural' // Most natural French voice
            },
            'zh': {
                'guide': 'enhanced_zh_female',    // Best available Chinese female
                'storyteller': 'enhanced_zh_male', // Best available Chinese male
                'conversational': 'enhanced_zh_natural' // Most natural Chinese voice
            }
        };

        const style = voiceStyle || 'conversational';
        const voiceId = voiceMapping[language]?.[style] || voiceMapping['en']['conversational'];

        // Return voice configuration for client-side synthesis
        // Using Web Speech API on client side is more efficient than server-side generation
        return new Response(JSON.stringify({
            data: {
                text: text,
                language: language,
                voiceId: voiceId,
                voiceStyle: style,
                config: {
                    lang: getVoiceLanguageCode(language),
                    rate: 0.95,
                    pitch: 1.0,
                    volume: 1.0
                }
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Voice synthesis error:', error);

        return new Response(JSON.stringify({
            error: {
                code: 'VOICE_SYNTHESIS_ERROR',
                message: error.message
            }
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// Get proper language code for Web Speech API
function getVoiceLanguageCode(language: string): string {
    const languageCodes = {
        'en': 'en-US',
        'es': 'es-ES',
        'hi': 'hi-IN',
        'ur': 'ur-PK',
        'ar': 'ar-SA',
        'fr': 'fr-FR',
        'zh': 'zh-CN'
    };
    return languageCodes[language] || 'en-US';
}
