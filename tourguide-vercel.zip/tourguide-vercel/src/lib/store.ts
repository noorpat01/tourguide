import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface ConversationState {
  conversationId: string | null;
  messages: Message[];
  language: string;
  location: GeolocationPosition | null;
  isLoading: boolean;
  error: string | null;
  
  setConversationId: (id: string) => void;
  addMessage: (message: Message) => void;
  setLanguage: (lang: string) => void;
  setLocation: (location: GeolocationPosition | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearConversation: () => void;
}

export const useConversationStore = create<ConversationState>()(
  persist(
    (set) => ({
      conversationId: null,
      messages: [],
      language: 'en',
      location: null,
      isLoading: false,
      error: null,
      
      setConversationId: (id) => set({ conversationId: id }),
      addMessage: (message) => set((state) => ({ 
        messages: [...state.messages, message] 
      })),
      setLanguage: (lang) => set({ language: lang }),
      setLocation: (location) => set({ location }),
      setLoading: (loading) => set({ isLoading: loading }),
      setError: (error) => set({ error }),
      clearConversation: () => set({ 
        conversationId: null,
        messages: [],
        error: null 
      })
    }),
    {
      name: 'conversation-storage',
      partialize: (state) => ({
        conversationId: state.conversationId,
        messages: state.messages,
        language: state.language
      })
    }
  )
);

interface AppState {
  voiceEnabled: boolean;
  offlineMode: boolean;
  locationPermission: boolean;
  branding: {
    appName: string;
    primaryColor: string;
    secondaryColor: string;
    logo: string | null;
  };
  
  toggleVoice: () => void;
  toggleOffline: () => void;
  setLocationPermission: (permission: boolean) => void;
  setBranding: (branding: Partial<AppState['branding']>) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      voiceEnabled: true,
      offlineMode: false,
      locationPermission: false,
      branding: {
        appName: 'AI Travel Guide',
        primaryColor: '#3B82F6',
        secondaryColor: '#10B981',
        logo: null
      },
      
      toggleVoice: () => set((state) => ({ voiceEnabled: !state.voiceEnabled })),
      toggleOffline: () => set((state) => ({ offlineMode: !state.offlineMode })),
      setLocationPermission: (permission) => set({ locationPermission: permission }),
      setBranding: (branding) => set((state) => ({
        branding: { ...state.branding, ...branding }
      }))
    }),
    {
      name: 'app-storage'
    }
  )
);
