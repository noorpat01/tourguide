import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { ChatInterface } from './components/ChatInterface';
import { Settings } from './components/Settings';
import { useAppStore, useConversationStore } from './lib/store';
import { MessageSquare, Settings as SettingsIcon } from 'lucide-react';
import './lib/i18n';

function App() {
  const { i18n } = useTranslation();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { branding } = useAppStore();
  const { language } = useConversationStore();

  // Apply RTL for Arabic and Urdu
  useEffect(() => {
    const isRTL = language === 'ar' || language === 'ur';
    document.dir = isRTL ? 'rtl' : 'ltr';
    i18n.changeLanguage(language);
  }, [language, i18n]);

  // Apply branding colors
  useEffect(() => {
    document.documentElement.style.setProperty('--primary-color', branding.primaryColor);
    document.documentElement.style.setProperty('--secondary-color', branding.secondaryColor);
  }, [branding]);

  return (
    <div className="h-screen flex flex-col bg-gray-50" style={{ 
      colorScheme: 'light',
      maxWidth: '100vw',
      overflow: 'hidden'
    }}>
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          {branding.logo ? (
            <img src={branding.logo} alt={branding.appName} className="h-8 w-8 object-contain" />
          ) : (
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-green-500 flex items-center justify-center">
              <MessageSquare size={20} className="text-white" />
            </div>
          )}
          <h1 className="text-lg font-bold text-gray-900">{branding.appName}</h1>
        </div>
        
        <button
          onClick={() => setIsSettingsOpen(true)}
          className="p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <SettingsIcon size={24} className="text-gray-600" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        <ChatInterface />
      </main>

      {/* Settings Modal */}
      <Settings isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </div>
  );
}

export default App;
