import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useConversationStore } from '../lib/store';

interface POIData {
  name: string;
  location: {
    latitude: number;
    longitude: number;
  };
  description?: string;
  address?: string;
  category?: string;
  rating?: number;
  thumbnail?: string;
}

export function usePOI() {
  const { location, language } = useConversationStore();
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchPOI = useCallback(async (query: string, radius: number = 5000): Promise<POIData | null> => {
    try {
      setIsSearching(true);
      setError(null);

      const requestBody: any = {
        query,
        language,
        radius
      };

      if (location) {
        requestBody.latitude = location.coords.latitude;
        requestBody.longitude = location.coords.longitude;
      }

      const { data, error: searchError } = await supabase.functions.invoke('poi-research', {
        body: requestBody
      });

      if (searchError) throw searchError;

      const poiData = data?.data?.poi || data?.poi;
      
      setIsSearching(false);
      return poiData || null;

    } catch (err) {
      const error = err as Error;
      console.error('POI search error:', error);
      setError(error.message);
      setIsSearching(false);
      return null;
    }
  }, [location, language]);

  return {
    searchPOI,
    isSearching,
    error
  };
}
