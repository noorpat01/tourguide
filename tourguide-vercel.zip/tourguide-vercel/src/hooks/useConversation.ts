import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useConversationStore } from '../lib/store';

export function useConversation() {
  const {
    conversationId,
    messages,
    language,
    location,
    setConversationId,
    addMessage,
    setLoading,
    setError
  } = useConversationStore();

  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = useCallback(async (message: string) => {
    try {
      setLoading(true);
      setError(null);
      setIsTyping(true);

      // Add user message immediately
      addMessage({ role: 'user', content: message });

      // Call AI conversation edge function
      const { data, error } = await supabase.functions.invoke('ai-conversation', {
        body: {
          message,
          language,
          location: location ? {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude
          } : null,
          conversationId
        }
      });

      if (error) throw error;

      const response = data?.data || data;
      
      // Add assistant message
      addMessage({ role: 'assistant', content: response.message });
      
      // Update conversation ID if new
      if (response.conversationId && response.conversationId !== conversationId) {
        setConversationId(response.conversationId);
      }

      setIsTyping(false);
      return response;

    } catch (err) {
      const error = err as Error;
      console.error('Conversation error:', error);
      setError(error.message);
      setIsTyping(false);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [conversationId, language, location, addMessage, setConversationId, setLoading, setError]);

  return {
    messages,
    sendMessage,
    isTyping,
    conversationId
  };
}
