import { useState, useCallback, useEffect } from 'react';
import { useAppStore } from '../lib/store';

export function useVoice() {
  const { voiceEnabled } = useAppStore();
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [ttsMode, setTtsMode] = useState<'enhanced' | 'basic' | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    if (!voiceEnabled) return;

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      
      setRecognition(recognitionInstance);
    }
  }, [voiceEnabled]);

  const speak = useCallback(async (text: string, language: string = 'en', voiceStyle: string = 'conversational') => {
    if (!voiceEnabled || !text) return;

    try {
      setIsSpeaking(true);

      // Enhanced voice selection for Web Speech API - immediate improvement
      if ('speechSynthesis' in window) {
        const voices = window.speechSynthesis.getVoices();
        
        // Enhanced voice mapping for better quality
        const enhancedVoiceMapping = {
          'en': {
            'guide': voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('female')) || 
                   voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('woman')) ||
                   voices.find(v => v.lang.startsWith('en')),
            'storyteller': voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('male')) ||
                          voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('man')) ||
                          voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('en') && v.name.toLowerCase().includes('natural')) ||
                                voices.find(v => v.lang.startsWith('en'))
          },
          'es': {
            'guide': voices.find(v => v.lang.startsWith('es') && v.name.toLowerCase().includes('female')) ||
                   voices.find(v => v.lang.startsWith('es')),
            'storyteller': voices.find(v => v.lang.startsWith('es') && v.name.toLowerCase().includes('male')) ||
                          voices.find(v => v.lang.startsWith('es')),
            'conversational': voices.find(v => v.lang.startsWith('es'))
          },
          'hi': {
            'guide': voices.find(v => v.lang.startsWith('hi')) || voices.find(v => v.lang.startsWith('en')), // Fallback to English
            'storyteller': voices.find(v => v.lang.startsWith('hi')) || voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('hi')) || voices.find(v => v.lang.startsWith('en'))
          },
          'ur': {
            'guide': voices.find(v => v.lang.startsWith('ur')) || voices.find(v => v.lang.startsWith('en')), // Fallback to English
            'storyteller': voices.find(v => v.lang.startsWith('ur')) || voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('ur')) || voices.find(v => v.lang.startsWith('en'))
          },
          'ar': {
            'guide': voices.find(v => v.lang.startsWith('ar')) || voices.find(v => v.lang.startsWith('en')), // Fallback to English
            'storyteller': voices.find(v => v.lang.startsWith('ar')) || voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('ar')) || voices.find(v => v.lang.startsWith('en'))
          },
          'fr': {
            'guide': voices.find(v => v.lang.startsWith('fr')) || voices.find(v => v.lang.startsWith('en')),
            'storyteller': voices.find(v => v.lang.startsWith('fr')) || voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('fr')) || voices.find(v => v.lang.startsWith('en'))
          },
          'zh': {
            'guide': voices.find(v => v.lang.startsWith('zh')) || voices.find(v => v.lang.startsWith('en')),
            'storyteller': voices.find(v => v.lang.startsWith('zh')) || voices.find(v => v.lang.startsWith('en')),
            'conversational': voices.find(v => v.lang.startsWith('zh')) || voices.find(v => v.lang.startsWith('en'))
          }
        };

        const selectedVoice = enhancedVoiceMapping[language]?.[voiceStyle] || enhancedVoiceMapping[language]?.conversational;
        
        const utterance = new SpeechSynthesisUtterance(text);
        
        if (selectedVoice) {
          utterance.voice = selectedVoice;
          console.log(`Using enhanced voice: ${selectedVoice.name} (${selectedVoice.lang})`);
        }
        
        const languageCodes: Record<string, string> = {
          'en': 'en-US',
          'es': 'es-ES',
          'hi': 'hi-IN',
          'ur': 'ur-PK',
          'ar': 'ar-SA',
          'fr': 'fr-FR',
          'zh': 'zh-CN'
        };
        
        utterance.lang = languageCodes[language] || 'en-US';
        utterance.rate = 0.9;  // Slower for better clarity
        utterance.pitch = 1.0; // Natural pitch
        utterance.volume = 1.0;

        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = (error) => {
          console.error('Speech synthesis error:', error);
          setIsSpeaking(false);
        };

        window.speechSynthesis.speak(utterance);
      }

    } catch (err) {
      console.error('Speech synthesis error:', err);
      setIsSpeaking(false);
    }
  }, [voiceEnabled]);

  const stopSpeaking = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const startListening = useCallback((language: string = 'en', onResult: (text: string) => void) => {
    if (!recognition || !voiceEnabled) {
      console.warn('Speech recognition not available');
      return;
    }

    const languageCodes: Record<string, string> = {
      'en': 'en-US',
      'es': 'es-ES',
      'hi': 'hi-IN',
      'ur': 'ur-PK',
      'ar': 'ar-SA',
      'fr': 'fr-FR',
      'zh': 'zh-CN'
    };

    recognition.lang = languageCodes[language] || 'en-US';
    
    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    try {
      recognition.start();
    } catch (err) {
      console.error('Failed to start recognition:', err);
      setIsListening(false);
    }
  }, [recognition, voiceEnabled]);

  const stopListening = useCallback(() => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
    }
  }, [recognition]);

  return {
    speak,
    stopSpeaking,
    startListening,
    stopListening,
    isSpeaking,
    isListening,
    isAvailable: !!recognition && voiceEnabled
  };
}
