import { useState, useEffect, useCallback } from 'react';
import { useConversationStore, useAppStore } from '../lib/store';

export function useLocation() {
  const { setLocation } = useConversationStore();
  const { locationPermission, setLocationPermission } = useAppStore();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const requestPermission = useCallback(async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return false;
    }

    try {
      setIsLoading(true);
      setError(null);

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });

      setLocation(position);
      setLocationPermission(true);
      setIsLoading(false);
      return true;

    } catch (err: any) {
      const errorMessage = err.code === 1 
        ? 'Location permission denied' 
        : err.code === 2 
        ? 'Location unavailable' 
        : 'Location request timeout';
      
      setError(errorMessage);
      setLocationPermission(false);
      setIsLoading(false);
      return false;
    }
  }, [setLocation, setLocationPermission]);

  const watchPosition = useCallback(() => {
    if (!navigator.geolocation || !locationPermission) return null;

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        setLocation(position);
      },
      (err) => {
        console.error('Watch position error:', err);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000
      }
    );

    return watchId;
  }, [locationPermission, setLocation]);

  const stopWatching = useCallback((watchId: number | null) => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  useEffect(() => {
    if (locationPermission) {
      const watchId = watchPosition();
      return () => stopWatching(watchId);
    }
  }, [locationPermission, watchPosition, stopWatching]);

  return {
    requestPermission,
    watchPosition,
    stopWatching,
    error,
    isLoading,
    hasPermission: locationPermission
  };
}
