"""
Coqui TTS API Wrapper for Vercel Deployment
Lightweight implementation optimized for Vercel's constraints:
- 15-second timeout limit
- 1GB memory limit  
- No GPU support
- Serverless environment
"""

import json
import logging
import os
import sys
import traceback
import urllib.parse
from datetime import datetime
from typing import Dict, Optional, Union

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Vercel environment constants
VERCEL_TTS_API_URL = os.environ.get('VERCEL_TTS_API_URL', 'https://api.coqui.ai/v2/inference')
VERCEL_TTS_API_KEY = os.environ.get('VERCEL_TTS_API_KEY', '')

class CoquiTTSError(Exception):
    """Custom exception for Coqui TTS errors"""
    pass

def cors_headers() -> Dict[str, str]:
    """Generate CORS headers for Vercel response"""
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    }

def get_language_code(language: str) -> str:
    """Map language codes to Coqui TTS supported formats"""
    language_mapping = {
        'en': 'en',      # English
        'es': 'es',      # Spanish  
        'hi': 'hi',      # Hindi
        'ur': 'ur',      # Urdu
        'ar': 'ar',      # Arabic
        'fr': 'fr',      # French
        'zh': 'zh'       # Chinese
    }
    return language_mapping.get(language, 'en')

def get_voice_style(style: str = 'conversational') -> str:
    """Map voice styles to Coqui TTS model names"""
    style_mapping = {
        'guide': 'tts_multilingual',
        'storyteller': 'tts_multilingual', 
        'conversational': 'tts_multilingual'
    }
    return style_mapping.get(style, 'tts_multilingual')

def chunk_text_for_vercel(text: str, max_chunk_size: int = 500) -> list:
    """Split text into chunks suitable for Vercel's 15s timeout"""
    # Split by sentences first, then by words if needed
    sentences = text.replace('!', '.').replace('?', '.').split('.')
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
            
        # If adding this sentence would exceed chunk size, start new chunk
        if len(current_chunk + sentence) > max_chunk_size and current_chunk:
            chunks.append(current_chunk.strip())
            current_chunk = sentence
        else:
            if current_chunk:
                current_chunk += ". " + sentence
            else:
                current_chunk = sentence
    
    # Add the last chunk if it exists
    if current_chunk.strip():
        chunks.append(current_chunk.strip())
    
    return chunks

def validate_input(text: str, language: str, voice_style: str) -> None:
    """Validate input parameters"""
    if not text or not text.strip():
        raise CoquiTTSError("Text cannot be empty")
    
    if not language:
        raise CoquiTTSError("Language is required")
    
    supported_languages = ['en', 'es', 'hi', 'ur', 'ar', 'fr', 'zh']
    if language not in supported_languages:
        raise CoquiTTSError(f"Language '{language}' not supported. Supported: {supported_languages}")
    
    supported_styles = ['guide', 'storyteller', 'conversational']
    if voice_style not in supported_styles:
        raise CoquiTTSError(f"Voice style '{voice_style}' not supported. Supported: {supported_styles}")

def generate_mock_tts_response(text: str, language: str, voice_style: str) -> Dict:
    """Generate mock TTS response for testing when Coqui API is not available"""
    return {
        "success": True,
        "data": {
            "text": text,
            "language": language,
            "voiceStyle": voice_style,
            "audioUrl": None,  # In mock mode, return None
            "config": {
                "lang": get_language_code(language),
                "rate": 0.95,
                "pitch": 1.0,
                "volume": 1.0,
                "chunkCount": len(chunk_text_for_vercel(text)),
                "mode": "mock"  # Indicate this is a mock response
            },
            "message": "Mock TTS response - Coqui API not configured"
        }
    }

def process_tts_request(text: str, language: str, voice_style: str = 'conversational') -> Dict:
    """
    Process TTS request with Vercel-optimized handling
    
    Args:
        text: Text to synthesize
        language: Language code (en, es, hi, ur, ar, fr, zh)
        voice_style: Voice style (guide, storyteller, conversational)
    
    Returns:
        Dict: TTS response data
    """
    try:
        # Validate input
        validate_input(text, language, voice_style)
        
        # Check if Coqui API is configured
        if not VERCEL_TTS_API_KEY:
            logger.warning("Coqui TTS API key not configured, returning mock response")
            return generate_mock_tts_response(text, language, voice_style)
        
        # Chunk text for Vercel's timeout limits
        chunks = chunk_text_for_vercel(text)
        chunk_count = len(chunks)
        
        # For now, return chunked processing info
        # In full implementation, this would call Coqui API for each chunk
        return {
            "success": True,
            "data": {
                "text": text,
                "language": language,
                "voiceStyle": voice_style,
                "audioUrl": None,  # Would contain actual audio URL from Coqui
                "config": {
                    "lang": get_language_code(language),
                    "rate": 0.95,
                    "pitch": 1.0,
                    "volume": 1.0,
                    "chunkCount": chunk_count,
                    "mode": "chunked"  # Indicates chunked processing
                },
                "message": f"Text processed in {chunk_count} chunks for Vercel compatibility"
            }
        }
        
    except CoquiTTSError as e:
        logger.error(f"Coqui TTS validation error: {e}")
        return {
            "success": False,
            "error": {
                "code": "VALIDATION_ERROR",
                "message": str(e)
            }
        }
    except Exception as e:
        logger.error(f"Coqui TTS processing error: {e}")
        logger.error(traceback.format_exc())
        return {
            "success": False,
            "error": {
                "code": "TTS_PROCESSING_ERROR", 
                "message": f"Failed to process TTS request: {str(e)}"
            }
        }

def handle_options_request():
    """Handle CORS preflight requests"""
    return {
        "statusCode": 200,
        "headers": cors_headers(),
        "body": ""
    }

def handle_get_request():
    """Handle GET requests with health check"""
    return {
        "statusCode": 200,
        "headers": cors_headers(),
        "body": json.dumps({
            "message": "Coqui TTS API is running",
            "version": "1.0.0",
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "supported_languages": ["en", "es", "hi", "ur", "ar", "fr", "zh"],
            "voice_styles": ["guide", "storyteller", "conversational"],
            "vercel_compatible": True
        })
    }

def main(request_data: Dict) -> Dict:
    """
    Main handler for Vercel serverless function
    
    Args:
        request_data: Dictionary containing request parameters
    
    Returns:
        Dict: Response data for Vercel
    """
    try:
        # Extract parameters from request
        text = request_data.get('text', '')
        language = request_data.get('language', 'en')
        voice_style = request_data.get('voiceStyle', 'conversational')
        
        # Process TTS request
        result = process_tts_request(text, language, voice_style)
        
        # Return response
        return {
            "statusCode": 200 if result["success"] else 400,
            "headers": cors_headers(),
            "body": json.dumps(result)
        }
        
    except Exception as e:
        logger.error(f"Main handler error: {e}")
        logger.error(traceback.format_exc())
        
        return {
            "statusCode": 500,
            "headers": cors_headers(),
            "body": json.dumps({
                "success": False,
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": f"Internal server error: {str(e)}"
                }
            })
        }