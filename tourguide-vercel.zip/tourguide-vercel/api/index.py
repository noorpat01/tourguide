"""
Vercel API Route for Coqui TTS Integration
Main entry point for TTS requests in Vercel serverless environment
"""

import json
from tts import main, handle_get_request, handle_options_request

def handler(request):
    """
    Main Vercel handler function
    
    Args:
        request: Vercel request object
    
    Returns:
        Response: Vercel response object
    """
    # Handle CORS preflight requests
    if request.method == 'OPTIONS':
        options_result = handle_options_request()
        return options_result
    
    # Handle GET requests (health check)
    if request.method == 'GET':
        get_result = handle_get_request()
        return get_result
    
    # Handle POST requests (TTS processing)
    if request.method == 'POST':
        try:
            # Parse request body
            request_data = json.loads(request.body.decode('utf-8'))
            
            # Process TTS request
            result = main(request_data)
            
            # Return response
            return result
            
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "headers": {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                "body": json.dumps({
                    "success": False,
                    "error": {
                        "code": "INVALID_JSON",
                        "message": "Invalid JSON in request body"
                    }
                })
            }
        except Exception as e:
            return {
                "statusCode": 500,
                "headers": {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                "body": json.dumps({
                    "success": False,
                    "error": {
                        "code": "PROCESSING_ERROR",
                        "message": f"Failed to process request: {str(e)}"
                    }
                })
            }
    
    # Method not allowed
    return {
        "statusCode": 405,
        "headers": {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        },
        "body": json.dumps({
            "success": False,
            "error": {
                "code": "METHOD_NOT_ALLOWED",
                "message": f"Method {request.method} not allowed"
            }
        })
    }